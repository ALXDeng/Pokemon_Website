import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import json
import os
import shutil
from PIL import Image 

class PokemonGameEditor:
    def __init__(self, root):
        self.root = root
        self.root.title("Pokémon Game Editor")
        
        self.pokemon_data = {}
        self.map_data = {"Pokemon": {}, "Entities": {}}
        
        self.notebook = ttk.Notebook(root)
        self.notebook.pack(expand=True, fill='both', padx=5, pady=5)
        
        self.create_pokemon_tab()
        self.create_map_tab()
        self.create_character_creator_tab()
        self.create_entity_creator_tab()
        
        self.load_data()

    def create_pokemon_tab(self):
        pokemon_frame = ttk.Frame(self.notebook)
        self.notebook.add(pokemon_frame, text='Pokémon Editor')
        
        list_frame = ttk.Frame(pokemon_frame)
        list_frame.pack(side='left', fill='y', padx=5, pady=5)
        
        ttk.Label(list_frame, text="Pokémon List").pack()
        self.pokemon_listbox = tk.Listbox(list_frame, width=20)
        self.pokemon_listbox.pack(fill='y', expand=True)
        self.pokemon_listbox.bind('<<ListboxSelect>>', self.on_pokemon_select)
        
        btn_frame = ttk.Frame(list_frame)
        btn_frame.pack(fill='x', pady=5)
        ttk.Button(btn_frame, text="Add", command=self.add_pokemon).pack(side='left', padx=2)
        ttk.Button(btn_frame, text="Delete", command=self.delete_pokemon).pack(side='left', padx=2)
        
        details_frame = ttk.LabelFrame(pokemon_frame, text="Pokémon Details")
        details_frame.pack(side='left', fill='both', expand=True, padx=5, pady=5)
        
        self.detail_entries = {}
        fields = [
            ("name", "Name:"),
            ("type", "Type:"),
            ("hp", "HP:"),
            ("attack", "Attack:"),
            ("animPath", "Animation Path:")
        ]
        
        for key, label in fields:
            frame = ttk.Frame(details_frame)
            frame.pack(fill='x', padx=5, pady=2)
            ttk.Label(frame, text=label).pack(side='left')
            
            if key == "type":
                types = ["Normal", "Fire", "Water", "Electric", "Grass", "Ice", 
                        "Fighting", "Poison", "Ground", "Flying", "Psychic", 
                        "Bug", "Rock", "Ghost", "Dragon", "Dark", "Steel", "Fairy"]
                entry = ttk.Combobox(frame, values=types)
            else:
                entry = ttk.Entry(frame)
            
            entry.pack(side='left', fill='x', expand=True, padx=5)
            self.detail_entries[key] = entry
            
        ttk.Button(details_frame, text="Save Changes", 
                  command=self.save_pokemon_details).pack(pady=10)

    def create_map_tab(self):
        map_frame = ttk.Frame(self.notebook)
        self.notebook.add(map_frame, text='Map Editor')
        
        control_frame = ttk.Frame(map_frame)
        control_frame.pack(side='left', fill='y', padx=5, pady=5)
        
        type_frame = ttk.LabelFrame(control_frame, text="Place Type")
        type_frame.pack(fill='x', pady=5)
        self.place_type = tk.StringVar(value="Pokemon")
        ttk.Radiobutton(type_frame, text="Pokémon", variable=self.place_type, 
                       value="Pokemon", command=self.update_placement_selector).pack()
        ttk.Radiobutton(type_frame, text="Entity", variable=self.place_type, 
                       value="Entities", command=self.update_placement_selector).pack()
        
        selector_frame = ttk.LabelFrame(control_frame, text="Select Item")
        selector_frame.pack(fill='x', pady=5)
        self.placement_selector = ttk.Combobox(selector_frame)
        self.placement_selector.pack(padx=5, pady=5)
        
        grid_frame = ttk.LabelFrame(map_frame, text="Map Grid")
        grid_frame.pack(side='left', fill='both', expand=True, padx=5, pady=5)
        
        self.grid_buttons = []
        for y in range(9):
            row = []
            for x in range(12):
                btn = ttk.Button(grid_frame, text='', width=5,
                               command=lambda x=x, y=y: self.on_grid_click(x, y))
                btn.grid(row=y, column=x, padx=1, pady=1)
                row.append(btn)
            self.grid_buttons.append(row)
            
        ttk.Button(control_frame, text="Save Map", 
                  command=self.save_map_data).pack(pady=5)
        type_frame = ttk.LabelFrame(control_frame, text="Place Type")
        type_frame.pack(fill='x', pady=5)
        self.place_type = tk.StringVar(value="Pokemon")
        ttk.Radiobutton(type_frame, text="Pokémon", variable=self.place_type, 
                    value="Pokemon", command=self.update_placement_selector).pack()
        ttk.Radiobutton(type_frame, text="Entity", variable=self.place_type, 
                    value="Entities", command=self.update_placement_selector).pack()
        ttk.Radiobutton(type_frame, text="Delete", variable=self.place_type,
                    value="Delete", command=self.update_placement_selector).pack()

    def create_character_creator_tab(self):
        creator_frame = ttk.Frame(self.notebook)
        self.notebook.add(creator_frame, text='Character Creator')
        
        info_frame = ttk.LabelFrame(creator_frame, text="Basic Information")
        info_frame.pack(side='left', fill='y', padx=5, pady=5)
        
        self.creator_entries = {}
        fields = [
            ("name", "Name:"),
            ("type", "Type:"),
            ("hp", "HP:"),
            ("attack", "Attack:")
        ]
        
        for key, label in fields:
            frame = ttk.Frame(info_frame)
            frame.pack(fill='x', padx=5, pady=2)
            ttk.Label(frame, text=label).pack(side='left')
            
            if key == "type":
                types = ["Normal", "Fire", "Water", "Electric", "Grass", "Ice", 
                        "Fighting", "Poison", "Ground", "Flying", "Psychic", 
                        "Bug", "Rock", "Ghost", "Dragon", "Dark", "Steel", "Fairy"]
                entry = ttk.Combobox(frame, values=types)
            else:
                entry = ttk.Entry(frame)
            entry.pack(side='left', fill='x', expand=True, padx=5)
            self.creator_entries[key] = entry
            
        sprite_frame = ttk.LabelFrame(creator_frame, text="Sprite Management")
        sprite_frame.pack(side='left', fill='both', expand=True, padx=5, pady=5)
        
        upload_frame = ttk.Frame(sprite_frame)
        upload_frame.pack(fill='x', padx=5, pady=5)
        
        self.sprite_path_var = tk.StringVar()
        ttk.Label(upload_frame, text="Sprite Sheet:").pack(side='left')
        ttk.Entry(upload_frame, textvariable=self.sprite_path_var, state='readonly').pack(side='left', fill='x', expand=True, padx=5)
        ttk.Button(upload_frame, text="Browse", command=self.browse_sprite).pack(side='left')
        
        config_frame = ttk.LabelFrame(sprite_frame, text="Sprite Sheet Configuration")
        config_frame.pack(fill='x', padx=5, pady=5)
        
        self.sprite_config = {}
        for key in ['frameWidth', 'frameHeight', 'columns', 'rows']:
            frame = ttk.Frame(config_frame)
            frame.pack(fill='x', padx=5, pady=2)
            ttk.Label(frame, text=f"{key}:").pack(side='left')
            entry = ttk.Entry(frame)
            entry.pack(side='left', fill='x', expand=True, padx=5)
            self.sprite_config[key] = entry
            
        anim_frame = ttk.LabelFrame(sprite_frame, text="Animation Configuration")
        anim_frame.pack(fill='x', padx=5, pady=5)
        
        self.animations_data = {}
        self.anim_listbox = tk.Listbox(anim_frame, height=5)
        self.anim_listbox.pack(fill='x', padx=5, pady=5)
        
        ctrl_frame = ttk.Frame(anim_frame)
        ctrl_frame.pack(fill='x', padx=5, pady=5)
        
        ttk.Button(ctrl_frame, text="Add Animation", 
                  command=self.add_animation).pack(side='left', padx=2)
        ttk.Button(ctrl_frame, text="Remove Animation", 
                  command=self.remove_animation).pack(side='left', padx=2)
        
        ttk.Button(creator_frame, text="Create Character", 
                  command=self.create_new_character).pack(pady=10)


    def create_entity_creator_tab(self):
        creator_frame = ttk.Frame(self.notebook)
        self.notebook.add(creator_frame, text='Entity Creator')
        
        info_frame = ttk.LabelFrame(creator_frame, text="Entity Information")
        info_frame.pack(side='left', fill='y', padx=5, pady=5)
        
        name_frame = ttk.Frame(info_frame)
        name_frame.pack(fill='x', padx=5, pady=2)
        ttk.Label(name_frame, text="Name:").pack(side='left')
        self.entity_name_entry = ttk.Entry(name_frame)
        self.entity_name_entry.pack(side='left', fill='x', expand=True, padx=5)
        
        sprite_frame = ttk.LabelFrame(creator_frame, text="Sprite Management")
        sprite_frame.pack(side='left', fill='both', expand=True, padx=5, pady=5)
        
        upload_frame = ttk.Frame(sprite_frame)
        upload_frame.pack(fill='x', padx=5, pady=5)
        
        self.entity_sprite_path_var = tk.StringVar()
        ttk.Label(upload_frame, text="Sprite:").pack(side='left')
        ttk.Entry(upload_frame, textvariable=self.entity_sprite_path_var, state='readonly').pack(side='left', fill='x', expand=True, padx=5)
        ttk.Button(upload_frame, text="Browse", command=self.browse_entity_sprite).pack(side='left')
        
        dim_frame = ttk.LabelFrame(sprite_frame, text="Sprite Dimensions")
        dim_frame.pack(fill='x', padx=5, pady=5)
        
        self.entity_dimensions = {}
        for key in ['width', 'height']:
            frame = ttk.Frame(dim_frame)
            frame.pack(fill='x', padx=5, pady=2)
            ttk.Label(frame, text=f"{key.capitalize()}:").pack(side='left')
            entry = ttk.Entry(frame)
            entry.pack(side='left', fill='x', expand=True, padx=5)
            self.entity_dimensions[key] = entry
        
        ttk.Button(creator_frame, text="Create Entity", 
                  command=self.create_new_entity).pack(pady=10)

    def browse_entity_sprite(self):
        filepath = filedialog.askopenfilename(
            filetypes=[("Bitmap files", "*.bmp"), ("All files", "*.*")]
        )
        if filepath:
            self.entity_sprite_path_var.set(filepath)
            try:
                with Image.open(filepath) as img:
                    width, height = img.size
                    self.entity_dimensions['width'].delete(0, tk.END)
                    self.entity_dimensions['width'].insert(0, str(width))
                    self.entity_dimensions['height'].delete(0, tk.END)
                    self.entity_dimensions['height'].insert(0, str(height))
            except Exception as e:
                messagebox.showwarning("Warning", f"Could not detect image dimensions: {e}")

    def create_new_entity(self):
        name = self.entity_name_entry.get().strip()
        if not name:
            messagebox.showerror("Error", "Name is required")
            return
            
        if not self.entity_sprite_path_var.get():
            messagebox.showerror("Error", "Sprite is required")
            return
            
        try:
            width = int(self.entity_dimensions['width'].get())
            height = int(self.entity_dimensions['height'].get())
        except ValueError:
            messagebox.showerror("Error", "Width and Height must be numbers")
            return
            
        entity_dir = f"assets/images/entities/{name.lower()}"
        os.makedirs(entity_dir, exist_ok=True)
        
        sprite_path = self.entity_sprite_path_var.get()
        new_sprite_path = f"{entity_dir}/{name.lower()}.bmp"
        shutil.copy2(sprite_path, new_sprite_path)
        
        anim_config = {
            "filepath": new_sprite_path,
            "format": {
                "width": width,
                "height": height,
                "tileWidth": width,
                "tileHeight": height
            },
            "frames": {
                "idle": [0]
            }
        }
        
        anim_path = f"{entity_dir}/{name.lower()}.json"
        with open(anim_path, 'w') as f:
            json.dump(anim_config, f, indent=2)
            
        try:
            with open('assets/configs/characters_entities/entities.json', 'r') as f:
                entities_data = json.load(f)
        except FileNotFoundError:
            entities_data = {}
            
        entities_data[name] = {
            "animPath": anim_path
        }
        
        with open('assets/configs/characters_entities/entities.json', 'w') as f:
            json.dump(entities_data, f, indent=2)
            
        messagebox.showinfo("Success", f"Entity '{name}' created successfully!")
        
        self.entity_name_entry.delete(0, tk.END)
        self.entity_sprite_path_var.set("")
        for entry in self.entity_dimensions.values():
            entry.delete(0, tk.END)
    
    def load_data(self):
        try:
            with open('assets/configs/characters_entities/pokemon.json', 'r') as f:
                self.pokemon_data = json.load(f)
                self.update_pokemon_list()
                
            with open('assets/configs/map/character_placements.json', 'r') as f:
                self.map_data = json.load(f)
                self.update_map_grid()
                
        except FileNotFoundError:
            messagebox.showwarning("Warning", "Config files not found. Starting with empty data.")
            
        self.update_placement_selector()

    def update_pokemon_list(self):
        self.pokemon_listbox.delete(0, tk.END)
        for name in self.pokemon_data:
            self.pokemon_listbox.insert(tk.END, name)

    def update_map_grid(self):
        for row in self.grid_buttons:
            for btn in row:
                btn.configure(text='')
                
        for pokemon_name, positions in self.map_data["Pokemon"].items():
            for pos in positions:
                if len(pos) == 2:  
                    x, y = pos
                    if 0 <= x < 12 and 0 <= y < 9:
                        self.grid_buttons[y][x].configure(text=pokemon_name[:2])
                        
        
        for entity_name, positions in self.map_data["Entities"].items():
            for pos in positions:
                if len(pos) == 2: 
                    x, y = pos
                    if 0 <= x < 12 and 0 <= y < 9:
                        self.grid_buttons[y][x].configure(text=entity_name[:2])


    def update_placement_selector(self):
        placement_type = self.place_type.get()
        if placement_type == "Delete":
            self.placement_selector['values'] = []
            self.placement_selector.set('')
            self.placement_selector.configure(state='disabled')
        else:
            self.placement_selector.configure(state='normal')
            if placement_type == "Pokemon":
                self.placement_selector['values'] = list(self.pokemon_data.keys())
            else: 
                try:
                    with open('assets/configs/characters_entities/entities.json', 'r') as f:
                        entities_data = json.load(f)
                        self.placement_selector['values'] = list(entities_data.keys())
                except FileNotFoundError:
                    self.placement_selector['values'] = []
            self.placement_selector.set('')

    def on_pokemon_select(self, event):
        selection = self.pokemon_listbox.curselection()
        if not selection:
            return
            
        name = self.pokemon_listbox.get(selection[0])
        pokemon = self.pokemon_data[name]
        
        
        for key, entry in self.detail_entries.items():
            entry.delete(0, tk.END)
            entry.insert(0, str(pokemon.get(key, '')))

    def add_pokemon(self):
        name = "New_Pokemon"
        i = 1
        while name in self.pokemon_data:
            name = f"New_Pokemon_{i}"
            i += 1
            
        self.pokemon_data[name] = {
            "name": name,
            "type": "Normal",
            "hp": 50,
            "attack": 50,
            "animPath": f"assets/images/pokemon/{name.lower()}/{name.lower()}.json"
        }
        
        self.update_pokemon_list()
        self.update_placement_selector()

    def delete_pokemon(self):
        selection = self.pokemon_listbox.curselection()
        if not selection:
            return
            
        name = self.pokemon_listbox.get(selection[0])
        if messagebox.askyesno("Confirm Delete", 
                             f"Are you sure you want to delete {name}?"):
            del self.pokemon_data[name]
            if name in self.map_data["Pokemon"]:
                del self.map_data["Pokemon"][name]
            self.update_pokemon_list()
            self.update_placement_selector()
            self.update_map_grid()

    def save_pokemon_details(self):
        selection = self.pokemon_listbox.curselection()
        if not selection:
            return
            
        name = self.pokemon_listbox.get(selection[0])
        pokemon = {}
        
        for key, entry in self.detail_entries.items():
            value = entry.get()
            if key in ['hp', 'attack']:
                try:
                    value = int(value)
                except ValueError:
                    messagebox.showerror("Error", f"Invalid value for {key}")
                    return
            pokemon[key] = value
            
        self.pokemon_data[name] = pokemon
        self.save_data()

    def on_grid_click(self, x, y):
        placement_type = self.place_type.get()
        
        if placement_type == "Delete":
            for category in ["Pokemon", "Entities"]:
                for name, positions in self.map_data[category].items():
                    if [x, y] in positions:
                        positions.remove([x, y])
            self.update_map_grid()
            return
            
        item_name = self.placement_selector.get()
        
        if not item_name:
            messagebox.showinfo("Info", "Please select an item to place")
            return
            
        for category in ["Pokemon", "Entities"]:
            for name, positions in self.map_data[category].items():
                if [x, y] in positions:
                    positions.remove([x, y])
                    
        if item_name not in self.map_data[placement_type]:
            self.map_data[placement_type][item_name] = []
            
        self.map_data[placement_type][item_name].append([x, y])
        self.update_map_grid()

    def browse_sprite(self):
        filepath = filedialog.askopenfilename(
            filetypes=[("Bitmap files", "*.bmp"), ("All files", "*.*")]
        )
        if filepath:
            self.sprite_path_var.set(filepath)
            # Get total image dimensions
            try:
                with Image.open(filepath) as img:
                    width, height = img.size
                    self.sprite_config['frameWidth'].delete(0, tk.END)
                    self.sprite_config['frameWidth'].insert(0, str(width))
                    self.sprite_config['frameHeight'].delete(0, tk.END)
                    self.sprite_config['frameHeight'].insert(0, str(height))
                    self.sprite_config['columns'].delete(0, tk.END)
                    self.sprite_config['columns'].insert(0, "1")
                    self.sprite_config['rows'].delete(0, tk.END)
                    self.sprite_config['rows'].insert(0, "1")
            except Exception as e:
                messagebox.showwarning("Warning", f"Could not detect image dimensions: {e}")
    def add_animation(self):
        dialog = AnimationDialog(self.root)
        if dialog.result:
            name, frames = dialog.result
            self.animations_data[name] = frames
            self.anim_listbox.insert(tk.END, name)
            
    def remove_animation(self):
        selection = self.anim_listbox.curselection()
        if selection:
            name = self.anim_listbox.get(selection[0])
            del self.animations_data[name]
            self.anim_listbox.delete(selection[0])

    def create_new_character(self):
        name = self.creator_entries['name'].get().strip()
        if not name:
            messagebox.showerror("Error", "Name is required")
            return
            
        if not self.sprite_path_var.get():
            messagebox.showerror("Error", "Sprite sheet is required")
            return
            
        try:
            hp = int(self.creator_entries['hp'].get())
            attack = int(self.creator_entries['attack'].get())
        except ValueError:
            messagebox.showerror("Error", "HP and Attack must be numbers")
            return
            
        char_dir = f"assets/images/pokemon/{name.lower()}"
        os.makedirs(char_dir, exist_ok=True)
        
        sprite_path = self.sprite_path_var.get()
        new_sprite_path = f"{char_dir}/{name.lower()}.bmp"
        shutil.copy2(sprite_path, new_sprite_path)
        
        anim_config = {
            "filepath": new_sprite_path,
            "format": {
                "width": int(self.sprite_config['columns'].get()) * int(self.sprite_config['frameWidth'].get()),
                "height": int(self.sprite_config['rows'].get()) * int(self.sprite_config['frameHeight'].get()),
                "tileWidth": int(self.sprite_config['frameWidth'].get()),
                "tileHeight": int(self.sprite_config['frameHeight'].get())
            },
            "frames": self.animations_data
        }
        
        anim_path = f"{char_dir}/{name.lower()}.json"
        with open(anim_path, 'w') as f:
            json.dump(anim_config, f, indent=2)
            
        self.pokemon_data[name] = {
            "name": name,
            "type": self.creator_entries['type'].get(),
            "hp": hp,
            "attack": attack,
            "animPath": anim_path,
            "visible": True

        }
        
        self.save_data()
        self.update_pokemon_list()
        self.update_placement_selector()
        
        messagebox.showinfo("Success", f"Character '{name}' created successfully!")
        
        for entry in self.creator_entries.values():
            entry.delete(0, tk.END)
        self.sprite_path_var.set("")
        for entry in self.sprite_config.values():
            entry.delete(0, tk.END)
        self.animations_data.clear()
        self.anim_listbox.delete(0, tk.END)

    def save_map_data(self):
        self.save_data()
        messagebox.showinfo("Success", "Map data saved successfully!")
        
    def save_data(self):
        with open('assets/configs/characters_entities/pokemon.json', 'w') as f:
            json.dump(self.pokemon_data, f, indent=2)
            
        with open('assets/configs/map/character_placements.json', 'w') as f:
            json.dump(self.map_data, f, indent=2)

class AnimationDialog:
    def __init__(self, parent):
        self.result = None
        
        dialog = tk.Toplevel(parent)
        dialog.title("Add Animation")
        
        name_frame = ttk.Frame(dialog)
        name_frame.pack(fill='x', padx=5, pady=5)
        ttk.Label(name_frame, text="Animation Name:").pack(side='left')
        self.name_entry = ttk.Entry(name_frame)
        self.name_entry.pack(side='left', fill='x', expand=True, padx=5)
        
        frames_frame = ttk.Frame(dialog)
        frames_frame.pack(fill='x', padx=5, pady=5)
        ttk.Label(frames_frame, text="Frame Numbers (comma-separated):").pack(side='left')
        self.frames_entry = ttk.Entry(frames_frame)
        self.frames_entry.pack(side='left', fill='x', expand=True, padx=5)
        
        btn_frame = ttk.Frame(dialog)
        btn_frame.pack(fill='x', padx=5, pady=5)
        ttk.Button(btn_frame, text="OK", command=lambda: self.ok(dialog)).pack(side='right', padx=5)
        ttk.Button(btn_frame, text="Cancel", command=dialog.destroy).pack(side='right')
        
        dialog.transient(parent)
        dialog.grab_set()
        parent.wait_window(dialog)
        
    def ok(self, dialog):
        name = self.name_entry.get().strip()
        frames_text = self.frames_entry.get().strip()
        
        try:
            frames = [int(f.strip()) for f in frames_text.split(',')]
            self.result = (name, frames)
            dialog.destroy()
        except ValueError:
            messagebox.showerror("Error", "Invalid frame numbers")

if __name__ == "__main__":
    root = tk.Tk()
    app = PokemonGameEditor(root)
    root.mainloop()