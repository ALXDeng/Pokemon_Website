var searchData=
[
  ['characternode_0',['characterNode',['../namespacegameapplication.html#a5606bc4aff2cfb78cf63d69704230513',1,'gameapplication']]],
  ['choices_1',['choices',['../structcomponents_1_1_dialogue_unit.html#af9688ccde0f0a9aaf2c1b541becc307a',1,'components::DialogueUnit']]]
];
