var searchData=
[
  ['name_0',['name',['../structcomponents_1_1_attack.html#af26c07b248098d424315eb94ffcfb121',1,'components::Attack']]]
];
