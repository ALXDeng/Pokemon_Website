var searchData=
[
  ['name_0',['name',['../structcomponents_1_1_attack.html#af26c07b248098d424315eb94ffcfb121',1,'components::Attack']]],
  ['next_1',['next',['../structcomponents_1_1_dialogue_unit.html#a1d7599b76d850e3e00b001836e152c2a',1,'components::DialogueUnit::next'],['../structcomponents_1_1_choice.html#af0b0652d593042f7212c9f2c128b4919',1,'components::Choice::next']]]
];
