var searchData=
[
  ['id_0',['id',['../structcomponents_1_1_dialogue_unit.html#a2fc708e75a86277c22972eb31a9a54df',1,'components::DialogueUnit']]],
  ['isplayer_1',['isPlayer',['../structcomponents_1_1_dialogue_unit.html#a71c19ca798724ba3d545cb9aa819b981',1,'components::DialogueUnit']]],
  ['istriggered_2',['isTriggered',['../classcomponents_1_1_battle_trigger_component.html#a3839afbc41a5679782f5091595fe701b',1,'components::BattleTriggerComponent']]]
];
