var searchData=
[
  ['delegate_0',['delegate',['../structcomponents_1_1_button.html#a25b8f86045d68b6941b144a215c9dcc1',1,'components::Button']]],
  ['displaypokemoninfo_1',['displayPokemonInfo',['../namespacecomponents.html#a6f0bc36671f8a73204ba9fae241b4152',1,'components']]]
];
