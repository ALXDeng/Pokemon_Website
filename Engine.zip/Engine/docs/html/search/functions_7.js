var searchData=
[
  ['onfightselected_0',['OnFightSelected',['../classcomponents_1_1_battle_menu_options.html#ab1277041286353f591c3d3f24ccae174',1,'components::BattleMenuOptions']]],
  ['onrunselected_1',['OnRunSelected',['../classcomponents_1_1_battle_menu_options.html#a15d04051250a68a83d6fef14af8269f1',1,'components::BattleMenuOptions']]]
];
