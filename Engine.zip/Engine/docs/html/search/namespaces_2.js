var searchData=
[
  ['factories_0',['factories',['../namespacefactories.html',1,'']]]
];
