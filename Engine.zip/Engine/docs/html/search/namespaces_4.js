var searchData=
[
  ['resourcemanager_0',['resourcemanager',['../namespaceresourcemanager.html',1,'']]]
];
