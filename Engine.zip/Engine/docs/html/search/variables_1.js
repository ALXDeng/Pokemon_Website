var searchData=
[
  ['damage_0',['damage',['../structcomponents_1_1_attack.html#ae496fa867624d8b6dc06f0f827ea0d70',1,'components::Attack']]],
  ['destrect_1',['destRect',['../classsprite_1_1_animated_sprite.html#ab6b673ec1964a78ae5ce502e72f68d22',1,'sprite::AnimatedSprite']]]
];
